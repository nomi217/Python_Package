from setuptools import setup, find_packages

# with open("README.md", 'r') as f:
#     long_description = f.read()

setup(
    name= "simple_calculator",
    version=0.1,
    description="A simple python calculator using modular programming",
    author="Nauman Khalid",
    author_email="naumankhalid217@gmail.com",
    packages=find_packages(),
    #requires=['numpy','pandas','scikit-learn'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Lisence ::OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
)